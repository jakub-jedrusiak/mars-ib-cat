var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
//------------------------------------------------------------------------------
// MaRS iFrame Results Saver
//------------------------------------------------------------------------------
import { registerEditor, registerSimple, component, ScreenComponent, } from "/client/participant/compiled/task-builder.js";
//------------------------------------------------------------------------------
let MarsIframeResultsSaver = class MarsIframeResultsSaver extends ScreenComponent {
    constructor() {
        super(...arguments);
        this.allowedOrigin = "";
        this.completed = false;
        this.messageHandler = null;
    }
    construct() {
        this.log("construct()");
        this.mainObjectBinding = this.createBinding();
        this.doneBinding = this.createBinding();
        this.thetaBinding = this.createBinding();
        this.semBinding = this.createBinding();
        this.reliabilityBinding = this.createBinding();
        this.itemCountBinding = this.createBinding();
        this.fullBinding = this.createBinding();
        super.construct();
    }
    apply(f) {
        this.allowedOrigin = (f.allowedOrigin || "").trim();
        this.log("apply()", {
            allowedOrigin: this.allowedOrigin || "*",
        });
        this.mainObjectBinding.parseIfExists(f.mainObjectDestination);
        this.doneBinding.parseIfExists(f.doneDestination);
        this.thetaBinding.parseIfExists(f.thetaDestination);
        this.semBinding.parseIfExists(f.semDestination);
        this.reliabilityBinding.parseIfExists(f.reliabilityDestination);
        this.itemCountBinding.parseIfExists(f.itemCountDestination);
        this.fullBinding.parseIfExists(f.fullDestination);
        super.apply(f);
    }
    screenStart() {
        super.screenStart();
        this.log("screenStart(): listening for postMessage");
        this.completed = false;
        this.messageHandler = (event) => {
            this.handleMessage(event);
        };
        window.addEventListener("message", this.messageHandler, false);
    }
    screenFinish() {
        this.log("screenFinish(): removing listeners");
        if (this.messageHandler) {
            window.removeEventListener("message", this.messageHandler, false);
            this.messageHandler = null;
        }
        super.screenFinish();
    }
    handleMessage(event) {
        if (this.completed) {
            this.log("message ignored: already completed");
            return;
        }
        if (!this.isAllowedOrigin(event.origin)) {
            this.log("message ignored: origin not allowed", {
                origin: event.origin,
                allowedOrigin: this.allowedOrigin,
            });
            return;
        }
        const msg = event.data;
        if (!msg || msg.type !== "MARS_RESULTS") {
            this.log("message ignored: not MARS_RESULTS", {
                type: msg && msg.type,
            });
            return;
        }
        if (!this.isValidPayload(msg.data)) {
            this.log("invalid payload received", msg.data);
            return;
        }
        this.log("valid MARS_RESULTS received", {
            itemCount: msg.data.itemCount,
            theta: msg.data.theta,
            reliability: msg.data.reliability,
        });
        this.savePayload(msg.data);
        this.completed = true;
        this.finishAfterReceive();
    }
    isAllowedOrigin(origin) {
        if (!this.allowedOrigin) {
            return true;
        }
        return origin === this.allowedOrigin;
    }
    isValidPayload(value) {
        if (!value || typeof value !== "object") {
            return false;
        }
        const payload = value;
        return (typeof payload.theta === "number" &&
            typeof payload.sem === "number" &&
            typeof payload.reliability === "number" &&
            typeof payload.itemCount === "number" &&
            Array.isArray(payload.responses) &&
            typeof payload.sessionStartMs === "number" &&
            typeof payload.sessionEndMs === "number");
    }
    savePayload(payload) {
        const json = JSON.stringify(payload);
        this.log("saving payload to Store fields");
        this.writeIfBound(this.mainObjectBinding, json);
        this.writeIfBound(this.fullBinding, json);
        this.writeIfBound(this.doneBinding, 1);
        this.writeIfBound(this.thetaBinding, payload.theta);
        this.writeIfBound(this.semBinding, payload.sem);
        this.writeIfBound(this.reliabilityBinding, payload.reliability);
        this.writeIfBound(this.itemCountBinding, payload.itemCount);
    }
    writeIfBound(binding, value) {
        try {
            binding.write(value);
            this.log("binding.write success");
        }
        catch (e) {
            this.log("binding.write failed (likely unbound field)", e);
        }
    }
    finishAfterReceive() {
        const self = this;
        this.log("attempting to advance/finish via triggerResponse");
        try {
            if (typeof self.triggerResponse === "function") {
                this.log("calling triggerResponse(ResponseType.Continue)");
                self.triggerResponse({
                    responseType: 2,
                    response: "mars_results_received",
                    tag: "mars_complete",
                    key: "mars_complete",
                });
                return;
            }
        }
        catch (e) {
            this.log("triggerResponse failed", e);
        }
        this.log("no runtime response trigger available; cannot auto-finish");
    }
    log(message, details) {
        if (typeof details === "undefined") {
            console.log("[MaRS iFrame Saver] " + message);
            return;
        }
        console.log("[MaRS iFrame Saver] " + message, details);
    }
};
MarsIframeResultsSaver = __decorate([
    component("task.component.MarsIframeResultsSaver")
], MarsIframeResultsSaver);
export { MarsIframeResultsSaver };
//------------------------------------------------------------------------------
registerEditor("MarsIframeResultsSaver", {
    label: "MaRS iFrame Saver",
    icon: "fas fa-database",
    form: {
        elements: [
            {
                class: "FormElementBindableText",
                field: "allowedOrigin",
                label: "Allowed postMessage origin (optional)",
            },
            {
                class: "FormElementBindableField",
                field: "mainObjectDestination",
                label: "Main object destination (e.g. marsMainObject)",
            },
            {
                class: "FormElementBindableField",
                field: "doneDestination",
                label: "Done destination (e.g. marsDone)",
            },
            {
                class: "FormElementBindableField",
                field: "thetaDestination",
                label: "Theta destination (e.g. marsData_theta)",
            },
            {
                class: "FormElementBindableField",
                field: "semDestination",
                label: "SEM destination (e.g. marsData_sem)",
            },
            {
                class: "FormElementBindableField",
                field: "reliabilityDestination",
                label: "Reliability destination (e.g. marsData_reliability)",
            },
            {
                class: "FormElementBindableField",
                field: "itemCountDestination",
                label: "Item count destination (e.g. marsData_itemCount)",
            },
            {
                class: "FormElementBindableField",
                field: "fullDestination",
                label: "Full JSON destination (e.g. marsFullResults)",
            },
        ],
    },
});
//------------------------------------------------------------------------------
registerSimple("screenComponent", "MarsIframeResultsSaver", {
    description: "Listens for MARS_RESULTS postMessage from an iFrame and saves payload values to bound Store fields.",
    category: "responseHandling",
});
//------------------------------------------------------------------------------
